import logging
logging.warning("loading jats_lib.py")
class JatsLib:

    def __init__(self):
        pass