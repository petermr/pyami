

class AmiChem:

    def __init__(self):
        pass


class AmiSpect:

    def __init__(self):
        pass

    def read_condensed_data(self, html):
        pass

    